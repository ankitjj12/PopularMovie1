package com.example.popularmovies;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

public class MovieAdapter extends RecyclerView.Adapter <MovieAdapter.MovieHolder> {

    Context ctx;
    String imageUrlAdp;

    public MovieAdapter(MainActivity mainActivity, String imageUrl) {
        ctx = mainActivity;
        imageUrlAdp = imageUrl;

    }

    @NonNull
    @Override
    public MovieHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(ctx);
        View myOwnView = layoutInflater.inflate(R.layout.movie_image,parent,false);
        return new MovieHolder(myOwnView);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieHolder holder, int position) {

        //Picasso.get().load("http://i.imgur.com/DvpvklR.png").into(holder.imageView);
        Picasso.with(ctx).load(imageUrlAdp).into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class MovieHolder extends RecyclerView.ViewHolder{
        public ImageView imageView;

        public MovieHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.movie_image);

        }
    }
}
